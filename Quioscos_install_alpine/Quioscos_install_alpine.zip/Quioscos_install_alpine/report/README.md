# Heartbeat en Alpine (OpenRC)

Archivos de referencia:
- `heartbeat.conf.example`: configuracion de URL principal/fallback y tiempos.
- `kioskmonitoring.openrc`: servicio OpenRC para mantener vivo el heartbeat.

## Instalacion sugerida
1. Copiar script de heartbeat:
```sh
sudo mkdir -p /opt/monitoring /etc/kiosk
sudo cp /ruta/monkiosk/kiosks_report/report_status.sh /opt/monitoring/report_status.sh
sudo chmod +x /opt/monitoring/report_status.sh
```

2. Copiar configuracion:
```sh
sudo cp /ruta/monkiosk/kiosks_report/alpine/heartbeat.conf.example /etc/kiosk/heartbeat.conf
sudo nano /etc/kiosk/heartbeat.conf
```

3. Instalar servicio OpenRC:
```sh
sudo cp /ruta/monkiosk/kiosks_report/alpine/kioskmonitoring.openrc /etc/init.d/kioskmonitoring
sudo chmod +x /etc/init.d/kioskmonitoring
sudo rc-update add kioskmonitoring default
sudo rc-service kioskmonitoring start
```

4. Comprobar estado:
```sh
rc-service kioskmonitoring status
tail -f /var/log/kiosk-heartbeat.log
```
